void SVM(int volts, unsigned int angle);
